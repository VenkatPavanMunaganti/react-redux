export const increment = () => {
    return {
        type: 'Increment'
    }
}

export const decrement = () => {
    return {
        type: 'Decrement'
    }
}

export const reset = () => {
    return {
        type: 'Reset'
    }
}
